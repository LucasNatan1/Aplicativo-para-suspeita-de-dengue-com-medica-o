package com.example.dengueprojeto;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private LinearLayout layoutResultados;
    private PacienteDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new PacienteDbHelper(this);
        layoutResultados = findViewById(R.id.layout_resultados);

        Button btnSalvar = findViewById(R.id.btn_salvar);
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarDadosPaciente();
            }
        });

        Button btnPesquisar = findViewById(R.id.btn_pesquisar);
        btnPesquisar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pesquisarPorRegiao();
            }
        });

        carregarPacientesSalvos();
    }

    private void salvarDadosPaciente() {
        EditText etNome = findViewById(R.id.edit_nome);
        EditText etIdade = findViewById(R.id.edit_idade);
        EditText etRegiao = findViewById(R.id.edit_regiao);
        EditText etSintomas = findViewById(R.id.edit_sintomas);

        String nome = etNome.getText().toString().trim();
        String idade = etIdade.getText().toString().trim();
        String regiao = etRegiao.getText().toString().trim();
        String sintomas = etSintomas.getText().toString().trim();

        if (TextUtils.isEmpty(nome) || TextUtils.isEmpty(idade) || TextUtils.isEmpty(regiao)) {
            Toast.makeText(this, "Preencha todos os campos obrigatórios", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(PacienteContract.PacienteEntry.COLUMN_NOME, nome);
        values.put(PacienteContract.PacienteEntry.COLUMN_IDADE, idade);
        values.put(PacienteContract.PacienteEntry.COLUMN_REGIAO, regiao);
        values.put(PacienteContract.PacienteEntry.COLUMN_SINTOMAS, sintomas);

        long newRowId = db.insert(PacienteContract.PacienteEntry.TABLE_NAME, null, values);

        if (newRowId == -1) {
            Toast.makeText(this, "Erro ao salvar o paciente", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Paciente salvo com sucesso", Toast.LENGTH_SHORT).show();
            etNome.setText("");
            etIdade.setText("");
            etRegiao.setText("");
            etSintomas.setText("");

            carregarPacientesSalvos();
        }
    }

    private void carregarPacientesSalvos() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] projection = {
                PacienteContract.PacienteEntry._ID,
                PacienteContract.PacienteEntry.COLUMN_NOME,
                PacienteContract.PacienteEntry.COLUMN_IDADE,
                PacienteContract.PacienteEntry.COLUMN_REGIAO,
                PacienteContract.PacienteEntry.COLUMN_SINTOMAS
        };

        Cursor cursor = db.query(
                PacienteContract.PacienteEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        layoutResultados.removeAllViews();

        while (cursor.moveToNext()) {
            final long pacienteId = cursor.getLong(cursor.getColumnIndexOrThrow(PacienteContract.PacienteEntry._ID));
            final String nome = cursor.getString(cursor.getColumnIndexOrThrow(PacienteContract.PacienteEntry.COLUMN_NOME));
            final String idade = cursor.getString(cursor.getColumnIndexOrThrow(PacienteContract.PacienteEntry.COLUMN_IDADE));
            final String regiao = cursor.getString(cursor.getColumnIndexOrThrow(PacienteContract.PacienteEntry.COLUMN_REGIAO));
            final String sintomas = cursor.getString(cursor.getColumnIndexOrThrow(PacienteContract.PacienteEntry.COLUMN_SINTOMAS));

            // Diagnosticar dengue
            boolean temSintomasCaracteristicos = verificaSintomasCaracteristicos(sintomas);
            String diagnostico = temSintomasCaracteristicos ? "Positivo" : "Negativo";
            String medicacao = temSintomasCaracteristicos ? "Medicação prescrita: Paracetamol" : "Nenhuma medicação necessária";


            View resultadoView = getLayoutInflater().inflate(R.layout.item_resultado, null);
            TextView tvNome = resultadoView.findViewById(R.id.text_nome);
            TextView tvDiagnostico = resultadoView.findViewById(R.id.text_diagnostico);
            Button btnEditar = resultadoView.findViewById(R.id.btn_editar);
            Button btnExcluir = resultadoView.findViewById(R.id.btn_excluir);

            tvNome.setText("Nome: " + nome);
            tvDiagnostico.setText("Suspeita de Dengue: " + diagnostico + "\n" + medicacao);

            btnEditar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mostrarDialogoEditar(pacienteId, nome, idade, regiao, sintomas);
                }
            });

            btnExcluir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    confirmarExclusaoPaciente(pacienteId);
                }
            });

            layoutResultados.addView(resultadoView);
        }

        cursor.close();
    }

    private void mostrarDialogoEditar(final long id, String nome, String idade, String regiao, String sintomas) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_editar_paciente, null);
        builder.setView(dialogView);

        final EditText etEditarNome = dialogView.findViewById(R.id.edit_nome_editar);
        final EditText etEditarIdade = dialogView.findViewById(R.id.edit_idade_editar);
        final EditText etEditarRegiao = dialogView.findViewById(R.id.edit_regiao_editar);
        final EditText etEditarSintomas = dialogView.findViewById(R.id.edit_sintomas_editar);

        etEditarNome.setText(nome);
        etEditarIdade.setText(idade);
        etEditarRegiao.setText(regiao);
        etEditarSintomas.setText(sintomas);

        builder.setTitle("Editar Paciente")
                .setPositiveButton("Salvar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String novoNome = etEditarNome.getText().toString().trim();
                        String novaIdade = etEditarIdade.getText().toString().trim();
                        String novaRegiao = etEditarRegiao.getText().toString().trim();
                        String novosSintomas = etEditarSintomas.getText().toString().trim();

                        editarPaciente(id, novoNome, novaIdade, novaRegiao, novosSintomas);
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void editarPaciente(long id, String novoNome, String novaIdade, String novaRegiao, String novosSintomas) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PacienteContract.PacienteEntry.COLUMN_NOME, novoNome);
        values.put(PacienteContract.PacienteEntry.COLUMN_IDADE, novaIdade);
        values.put(PacienteContract.PacienteEntry.COLUMN_REGIAO, novaRegiao);
        values.put(PacienteContract.PacienteEntry.COLUMN_SINTOMAS, novosSintomas);

        String selection = PacienteContract.PacienteEntry._ID + "=?";
        String[] selectionArgs = { String.valueOf(id) };

        int count = db.update(
                PacienteContract.PacienteEntry.TABLE_NAME,
                values,
                selection,
                selectionArgs);

        if (count > 0) {
            Toast.makeText(this, "Paciente atualizado com sucesso", Toast.LENGTH_SHORT).show();
            carregarPacientesSalvos();
        } else {
            Toast.makeText(this, "Erro ao atualizar o paciente", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmarExclusaoPaciente(final long id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Tem certeza que deseja excluir este paciente?")
                .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        excluirPaciente(id);
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void excluirPaciente(long id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        String selection = PacienteContract.PacienteEntry._ID + "=?";
        String[] selectionArgs = { String.valueOf(id) };

        int deletedRows = db.delete(PacienteContract.PacienteEntry.TABLE_NAME, selection, selectionArgs);

        if (deletedRows > 0) {
            Toast.makeText(this, "Paciente excluído com sucesso", Toast.LENGTH_SHORT).show();
            carregarPacientesSalvos(); // Recarrega a lista de pacientes após a exclusão
        } else {
            Toast.makeText(this, "Erro ao excluir o paciente", Toast.LENGTH_SHORT).show();
        }
    }

    private void pesquisarPorRegiao() {
        EditText etRegiaoPesquisa = findViewById(R.id.edit_regiao_pesquisa);
        String regiaoPesquisa = etRegiaoPesquisa.getText().toString().trim();

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] projection = {
                PacienteContract.PacienteEntry._ID,
                PacienteContract.PacienteEntry.COLUMN_NOME,
                PacienteContract.PacienteEntry.COLUMN_IDADE,
                PacienteContract.PacienteEntry.COLUMN_REGIAO,
                PacienteContract.PacienteEntry.COLUMN_SINTOMAS
        };

        String selection = PacienteContract.PacienteEntry.COLUMN_REGIAO + " LIKE ?";
        String[] selectionArgs = {"%" + regiaoPesquisa + "%"};

        Cursor cursor = db.query(
                PacienteContract.PacienteEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        layoutResultados.removeAllViews();
        int countDengue = 0; // Contador para pacientes com dengue

        while (cursor.moveToNext()) {
            final long pacienteId = cursor.getLong(cursor.getColumnIndexOrThrow(PacienteContract.PacienteEntry._ID));
            final String nome = cursor.getString(cursor.getColumnIndexOrThrow(PacienteContract.PacienteEntry.COLUMN_NOME));
            final String idade = cursor.getString(cursor.getColumnIndexOrThrow(PacienteContract.PacienteEntry.COLUMN_IDADE));
            final String regiao = cursor.getString(cursor.getColumnIndexOrThrow(PacienteContract.PacienteEntry.COLUMN_REGIAO));
            final String sintomas = cursor.getString(cursor.getColumnIndexOrThrow(PacienteContract.PacienteEntry.COLUMN_SINTOMAS));

            // Diagnosticar dengue
            boolean temSintomasCaracteristicos = verificaSintomasCaracteristicos(sintomas);
            String diagnostico = temSintomasCaracteristicos ? "Positivo" : "Negativo";
            String medicacao = temSintomasCaracteristicos ? "Medicação prescrita: Paracetamol" : "Nenhuma medicação necessária";


            if (temSintomasCaracteristicos) {
                countDengue++;
            }


            View resultadoView = getLayoutInflater().inflate(R.layout.item_resultado, null);
            TextView tvNome = resultadoView.findViewById(R.id.text_nome);
            TextView tvDiagnostico = resultadoView.findViewById(R.id.text_diagnostico);
            Button btnEditar = resultadoView.findViewById(R.id.btn_editar);
            Button btnExcluir = resultadoView.findViewById(R.id.btn_excluir);

            tvNome.setText("Nome: " + nome);
            tvDiagnostico.setText("Suspeita de Dengue: " + diagnostico + "\n" + medicacao);

            btnEditar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mostrarDialogoEditar(pacienteId, nome, idade, regiao, sintomas);
                }
            });

            btnExcluir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    confirmarExclusaoPaciente(pacienteId);
                }
            });

            layoutResultados.addView(resultadoView);
        }

        cursor.close();


        TextView tvQuantidadeDengue = findViewById(R.id.text_quantidade_dengue);
        tvQuantidadeDengue.setText("Pacientes com Dengue: " + countDengue);
    }

    private boolean verificaSintomasCaracteristicos(String sintomas) {

        return sintomas.toLowerCase().contains("febre alta") && sintomas.toLowerCase().contains("dor de cabeça intensa");
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
