package com.example.dengueprojeto;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PacienteDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Pacientes.db";
    private static final int DATABASE_VERSION = 1;

    public PacienteDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        final String SQL_CREATE_PACIENTES_TABLE = "CREATE TABLE " + PacienteContract.PacienteEntry.TABLE_NAME + " (" +
                PacienteContract.PacienteEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                PacienteContract.PacienteEntry.COLUMN_NOME + " TEXT NOT NULL, " +
                PacienteContract.PacienteEntry.COLUMN_IDADE + " TEXT NOT NULL, " +
                PacienteContract.PacienteEntry.COLUMN_REGIAO + " TEXT NOT NULL, " +
                PacienteContract.PacienteEntry.COLUMN_SINTOMAS + " TEXT NOT NULL" + ");";

        db.execSQL(SQL_CREATE_PACIENTES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + PacienteContract.PacienteEntry.TABLE_NAME);
        onCreate(db);
    }
}
