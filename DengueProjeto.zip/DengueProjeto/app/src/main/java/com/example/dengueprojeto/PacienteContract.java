package com.example.dengueprojeto;

import android.provider.BaseColumns;

public final class PacienteContract {

    private PacienteContract() {}

    public static class PacienteEntry implements BaseColumns {
        public static final String TABLE_NAME = "pacientes";
        public static final String COLUMN_NOME = "nome";
        public static final String COLUMN_IDADE = "idade";
        public static final String COLUMN_REGIAO = "regiao";
        public static final String COLUMN_SINTOMAS = "sintomas";
    }
}
